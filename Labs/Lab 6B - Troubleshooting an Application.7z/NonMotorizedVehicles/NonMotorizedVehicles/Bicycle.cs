﻿using Enumerations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NonMotorizedVehicles
{
    public class Bicycle : BaseNonMotorizedVehicle
    {
        public TerrainType TerrainType;

        public int NoOfTires { get; set; }
        public string Brakes { get; set; }

        public static bool Moving()
        {
            throw new NotImplementedException();
        }
    }
}
