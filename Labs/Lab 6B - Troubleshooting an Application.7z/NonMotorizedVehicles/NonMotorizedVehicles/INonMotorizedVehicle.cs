﻿using Enumerations;

namespace NonMotorizedVehicles
{
    public class NonMotorizedVehicle
    {
        
        bool HasPedals { get; set; }
        int NoOfWheels { get; set; }
        TerrainType TerrainType { get; set; }

        //public void bool Moving();
        //public void bool Moving(bool isMoving);
    }
}
