﻿using Enumerations;
using NonMotorizedVehicles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structures
{
    public class Tricycle : BaseNonMotorizedVehicle
    {
        public TerrainType TerrainType;

        public int NoOfTires { get; set; }
        public string Brakes { get; set; }

        public bool Moving()
        {
            throw new NotImplementedException();
        }
    }
}
