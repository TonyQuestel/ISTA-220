﻿using Enumerations;
using NonMotorizedVehicles;
using Structures;
using System;

namespace ConsumeNonMotorizedVehicles
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Bicycle bike = new Bicycle();
                bike.TerrainType = TerrainType.Beach;
                int NoOfWheels = 2;


                Tricycle trike = new Tricycle();
                trike.TerrainType = TerrainType.City;
                int NoOfTires = 3;

                Bicycle bikeTwin = new Bicycle();
                bikeTwin.TerrainType = TerrainType.AllTerrain;
                Console.WriteLine(value: $"bike has terrain type {bike.TerrainType}");
               

                Tricycle trikeTwin = new Tricycle();
                trikeTwin.TerrainType = TerrainType.Mountain;
                Console.WriteLine(value: $"trike has terrain type {trikeTwin.TerrainType}");
            
            }
            catch (Exception e)
            { throw e; }


        }
    }
}
