﻿using System;
using System.Collections.Generic;

namespace CL7_Tony_Questel___EX_6B___Generic_Collections
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("This is a List");
            List();
            Console.WriteLine(" ");
            Console.WriteLine("This is a linked List");
            LinkedList();
            Console.WriteLine(" ");
            Console.WriteLine("This is a Queue.");
            Queue();
            Console.WriteLine(" ");
            Console.WriteLine("This is a stack");
            Stack();
            Console.WriteLine(" ");
            Console.WriteLine("This is a Dictionary");
            Dictionary();
            Console.WriteLine(" ");
            Console.WriteLine("This is a SortedList");
            SortedList();
            Console.WriteLine(" ");
            Console.WriteLine("This is a HashList");
            hashList();
        }
        static void List()
        {
            List<int> list = new List<int>();
            list.Add(1);
            list.Add(2);
            list.Add(3);
            list.Add(4);
            list.Add(5);

            foreach (int i in list)
            {
                Console.WriteLine(i);
            }
        }
        static void LinkedList()
        {
            LinkedList<int> lList = new LinkedList<int>();
            lList.AddLast(6);
            lList.AddFirst(1);
            lList.AddFirst(4);
            lList.AddFirst(7);
            lList.AddFirst(2);
            foreach (int i in lList)
            {
                Console.WriteLine(i);
            }
        }
        static void Queue()
        {
            Queue<int> placeInLine = new Queue<int>();
            placeInLine.Enqueue(1);
            placeInLine.Enqueue(3);
            placeInLine.Enqueue(0);
            placeInLine.Enqueue(9);
            placeInLine.Enqueue(4);
            placeInLine.Enqueue(5);

            foreach (int i in placeInLine)
            {
                Console.WriteLine(i);
            }
        }
        static void Stack()
        {
            Stack<int> stacks = new Stack<int>();
            stacks.Push(1);
            stacks.Push(3);
            stacks.Push(5);
            stacks.Push(7);
            stacks.Push(9);
            foreach (int i in stacks)
            {
                Console.WriteLine(i);
            }
        }
        static void Dictionary()
        {
            Dictionary<string, string> websters = new Dictionary<string, string>();
            websters.Add("Ocean", "Whale");
            websters.Add("Forrest", "Jaguar");
            websters.Add("River", "Catfish");
            websters.Add("Desert", "Snake");
            websters.Add("Tundra", "Polar Bear");
            foreach (KeyValuePair<string, string> kvp in websters)
            {
                Console.WriteLine($"Key = {0}, Value = {1}", kvp.Key, kvp.Value);
            }
        }
        static void SortedList()
        {
            SortedList<int, string> pairs = new SortedList<int, string>();
            pairs.Add(1, "one");
            pairs.Add(2, "two");
            pairs.Add(3, "three");
            pairs.Add(4, "four");
            pairs.Add(5, "five");

            foreach (KeyValuePair<int, string> kvp in pairs)
            {
                Console.WriteLine($"The Key = {0}, Value = {1}", kvp.Key, kvp.Value);
            }
        }
        static void hashList()
        {
            HashSet<int> hash = new HashSet<int>();
            hash.Add(1);
            hash.Add(3);
            hash.Add(2);
            hash.Add(4);
            hash.Add(5);
            foreach (int i in hash)
            {
                Console.WriteLine(i);
            }
        }
    }
}
