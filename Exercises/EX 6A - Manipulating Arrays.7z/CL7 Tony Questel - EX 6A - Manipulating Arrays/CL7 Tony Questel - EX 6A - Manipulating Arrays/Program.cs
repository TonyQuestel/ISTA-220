﻿using System;

namespace CL7_Tony_Questel___EX_6A___Manipulating_Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 0;
            int sum = 0;
            double mean = 0;

            int[] arrayA = { 0, 2, 4, 6, 8, 10 };
            int[] arrayB = { 1, 3, 5, 7, 9 };
            int[] arrayC = { 3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 9 };

            Console.WriteLine("Part 1: Number of Elements, Sum, and Average");

            foreach (int element in arrayA)
            {
                number++;
                sum = sum + element;
            }

            mean = sum / number;

            Console.WriteLine($"\nThe number of elements in array A is {number}");
            Console.WriteLine($"The sum of the elements in array A is {sum}");
            Console.WriteLine($"The mean of array A is {mean}");

            //resetting global variables
            number = 0;
            sum = 0;


            foreach (int element in arrayB)
            {
                number++;
                sum = sum + element;
            }

            mean = sum / number;

            Console.WriteLine($"\nThe number of elements in array B is {number}");
            Console.WriteLine($"The sum of the elements in array B is {sum}");
            Console.WriteLine($"The mean of array B is {mean}");

            //resetting global variables
            number = 0;
            sum = 0;


            foreach (int element in arrayC)
            {
                number++;
                sum = sum + element;
            }

            mean = (double)sum / number;

            Console.WriteLine($"\nThe number of elements in array C is {number}");
            Console.WriteLine($"The sum of the elements in array C is {sum}");
            Console.WriteLine($"The mean of array C is {mean}\n");


            //Part 2. Reversing the Arrays
            Reverse(arrayA, arrayB, arrayC);


            //Part 3. Rotating the array. A direction of 0 = left and 1 = right. 2nd parameter is the number of places to rotate
            Console.WriteLine("\n\n\nPart 3: Rotating the arrays");
            Console.WriteLine("\nArray A rotated 2 to the left is:");
            Rotate(0, 2, arrayA);

            Console.WriteLine("\n\nArray B rotated 2 to the right is:");
            Rotate(1, 2, arrayB);

            Console.WriteLine("\n\nArray C rotated 4 to the left is:");
            Rotate(0, 4, arrayC);

            //Part 4. Sorting the arrays
            Sort(arrayC);
        }

        static void Reverse(int[] arrayA, int[] arrayB, int[] arrayC)
        {
            Console.WriteLine("\nPart 2: Reversing the Arrays.");
            Console.WriteLine("\nThe reverse of array A is: ");
            for (int i = arrayA.Length - 1; i >= 0; i--)
            {
                Console.Write($"{arrayA[i]} ");
            }

            Console.WriteLine("\nThe reverse of array B is: ");
            for (int i = arrayB.Length - 1; i >= 0; i--)
            {
                Console.Write($"{arrayB[i]} ");
            }

            Console.WriteLine("\nThe reverse of array C is: ");
            for (int i = arrayC.Length - 1; i >= 0; i--)
            {
                Console.Write($"{arrayC[i]} ");
            }
            
        }
        
        static void Rotate(int dir, int rotations, int[] p)
        {
            int[] result = new int[p.Length];

            if (dir == 0)
            {
                for (int i = 0; i < p.Length; i++)
                {
                    int pos = (i + rotations) % p.Length;
                    result[i] = p[pos];
                }
                foreach (int e in result)
                {
                    Console.Write(e + " ");
                }
            }
            else
            {
                for (int i = 0; i < p.Length; i++)
                {
                    result[(i + rotations) % p.Length] = p[i];
                }
                foreach (int e in result)
                {
                    Console.Write(e + " ");
                }
            }

        }
        static void Sort(int[] arrayC)
        {
           Console.WriteLine("\n\n\nPart 4: Sorting an array.\n\nArray C sorted is:");
           int temp;
           for (int j = 0; j < arrayC.Length - 1; j++)
           {
               for (int i = 0; i < arrayC.Length - 1; i++)
                   if (arrayC[i] > arrayC[i + 1])
                   {
                       temp = arrayC[i + 1];
                        arrayC[i + 1] = arrayC[i];
                        arrayC[i] = temp;
                   }
           }
               foreach (int number in arrayC)
               Console.Write(number + " ");
               Console.ReadKey();
        }

    }
}
